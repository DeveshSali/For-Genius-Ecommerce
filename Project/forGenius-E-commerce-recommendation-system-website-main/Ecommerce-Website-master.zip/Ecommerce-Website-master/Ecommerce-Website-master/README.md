# Ecommerce-Website
This is an complete Ecommerce Website I built. It has a product recommendation system to assist customers in making informed choices while purchasing items, an integrated PayPal payment checkout and an effective admin site to manage products on the site and customer orders.
I am constantly updating the frontend to improve the user experience.
It is not out for production yet. This is still the development stage.

# Technologies
The website is built using the Django framework. I have also employed Bootstrap for customizing the frontend.
The recommendation system is built upon Redis which enables fast data retrival

# BE Project Android Studio (oneQshop)
Demo: https://youtu.be/-Psl9HTsxXU
<br>
Backend Code: https://github.com/dms24081999/oneQshop-Backend

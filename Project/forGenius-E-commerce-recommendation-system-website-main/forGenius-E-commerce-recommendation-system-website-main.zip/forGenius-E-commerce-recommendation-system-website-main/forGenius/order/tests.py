from django.test import TestCase

# Create your tests here.
# We do all of the test via postman instead of this